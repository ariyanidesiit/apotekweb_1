<?php
    $host="localhost";
	$user="root";
	$pass="";
	$db="apotek";

	$connection =mysqli_connect($host, $user, $pass, $db) or die ("Connection Failed");
?>